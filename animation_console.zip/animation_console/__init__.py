bl_info = {
    "name": "Animation Console",
    "blender": (4, 1, 0),
    "category": "Animation",
    "author": "Syam Kalyan Yenubari",
    "description": "Console for quick animation controls and mirroring poses."
}


import bpy
from bpy.props import StringProperty, CollectionProperty
import mathutils
import json



# Create a new tab in the sidebar named "animator_console"
def create_console_tab():
    bpy.utils.register_class(AnimatorConsolePanel)
    

class AnimatorConsolePanel(bpy.types.Panel):
    bl_label = "Animator Console"
    bl_idname = "PT_animator_console"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'animator_console'

    def draw(self, context):
        layout = self.layout

        # Create the "Open Console" button
        layout.prop(context.window_manager, "open_console")

        # If the console is open, display the console window
        if context.window_manager.open_console:
            layout.label(text="Locations")
            row = layout.row()
            row.scale_y = 2.0
            row.alignment = 'CENTER'
            row.operator("object.translate_x_5", icon='SORT_DESC')
            
            row.label(text="                ")
            
            row.scale_y = 2.0
            row.alignment = 'RIGHT'
            row.operator("object.translate_z_5", icon='SORT_DESC')
            
            row = layout.row()
            row.alignment = 'CENTER'
            row.operator("object.translate_x_1", icon='SORT_DESC')
            
            row.label(text="                ")
            
            row.alignment = 'RIGHT'
            row.operator("object.translate_z_1", icon='SORT_DESC')
            
            #translate y axis menu
            row = layout.row()
            row.scale_y = 1.0
            row.alignment = 'CENTER'
            row.operator("object.translate_y_n5", icon='BACK')
            
            row.alignment = 'CENTER'
            row.operator("object.translate_y_n1", icon='BACK')
            
            row.label(text="")
            
            row.alignment = 'CENTER'
            row.operator("object.translate_y_1", icon='FORWARD')
            
            row.scale_x= 3.0
            row.alignment = 'CENTER'
            row.operator("object.translate_y_5", icon='FORWARD')
            row.label(text="")
            
            
            row = layout.row()
            row.alignment = 'CENTER'
            row.operator("object.translate_x_n1", icon='SORT_ASC')
            
            row.label(text="                ")
            
            row.alignment = 'RIGHT'
            row.operator("object.translate_z_n1", icon='SORT_ASC')
            
            row = layout.row()
            row.scale_y = 2.0
            row.alignment = 'CENTER'
            row.operator("object.translate_x_n5", icon='SORT_ASC')
            
            row.label(text="                ")
            
            row.scale_y = 2.0
            row.alignment = 'RIGHT'
            row.operator("object.translate_z_n5", icon='SORT_ASC')
            
            
            
            layout.label(text="Rotations")
            
            row = layout.row()
            row.scale_y = 2.0
            row.alignment = 'CENTER'
            row.operator("object.rotate_x_5", icon='SORT_DESC')

            row.label(text="                ")

            row.scale_y = 2.0
            row.alignment = 'RIGHT'
            row.operator("object.rotate_z_5", icon='SORT_DESC')

            row = layout.row()
            row.alignment = 'CENTER'
            row.operator("object.rotate_x_1", icon='SORT_DESC')

            row.label(text="                ")

            row.alignment = 'RIGHT'
            row.operator("object.rotate_z_1", icon='SORT_DESC')

            #rotate y axis menu
            row = layout.row()
            row.scale_y = 1.0
            row.alignment = 'CENTER'
            row.operator("object.rotate_y_n5", icon='BACK')

            row.alignment = 'CENTER'
            row.operator("object.rotate_y_n1", icon='BACK')

            row.label(text="")

            row.alignment = 'CENTER'
            row.operator("object.rotate_y_1", icon='FORWARD')

            row.scale_x= 3.0
            row.alignment = 'CENTER'
            row.operator("object.rotate_y_5", icon='FORWARD')
            row.label(text="")

            row = layout.row()
            row.alignment = 'CENTER'
            row.operator("object.rotate_x_n1", icon='SORT_ASC')

            row.label(text="                ")

            row.alignment = 'RIGHT'
            row.operator("object.rotate_z_n1", icon='SORT_ASC')

            row = layout.row()
            row.scale_y = 2.0
            row.alignment = 'CENTER'
            row.operator("object.rotate_x_n5", icon='SORT_ASC')

            row.label(text="                ")

            row.scale_y = 2.0
            row.alignment = 'RIGHT'
            row.operator("object.rotate_z_n5", icon='SORT_ASC')
            

# Create a button named "open console"
def create_console_button():
    bpy.types.WindowManager.open_console = bpy.props.BoolProperty(name="Open Console", default=False)

# Define the translation and rotation operators
class TranslateX5(bpy.types.Operator):
    bl_idname = "object.translate_x_5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.x += 5
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.location.x += 5
            return {'FINISHED'}

class TranslateX1(bpy.types.Operator):
    bl_idname = "object.translate_x_1"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.x += 1
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                    obj.location.x += 1
            return {'FINISHED'}

class TranslateXn5(bpy.types.Operator):
    bl_idname = "object.translate_x_n5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.x -= 5
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                    obj.location.x -= 5
            return {'FINISHED'}

class TranslateXn1(bpy.types.Operator):
    bl_idname = "object.translate_x_n1"
    bl_label = ""

    def execute(self, context):
          if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.x -= 1
            return {'FINISHED'}
          else:
              for obj in context.selected_objects:
                  obj.location.x -= 1
              return {'FINISHED'}

class TranslateY5(bpy.types.Operator):
    bl_idname = "object.translate_y_5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.y += 5
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                    obj.location.y += 5
            return {'FINISHED'}

class TranslateYn5(bpy.types.Operator):
    bl_idname = "object.translate_y_n5"
    bl_label = ""

    def execute(self, context):
          if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.y -= 5
            return {'FINISHED'}
          else:
            for obj in context.selected_objects:
                obj.location.y -= 5
            return {'FINISHED'}

class TranslateY1(bpy.types.Operator):
    bl_idname = "object.translate_y_1"
    bl_label = ""

    def execute(self, context):
          if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.y += 1
            return {'FINISHED'}
          else:
            for obj in context.selected_objects:
                obj.location.y += 1
            return {'FINISHED'}

class TranslateYn1(bpy.types.Operator):
    bl_idname = "object.translate_y_n1"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.y -= 1
            return {'FINISHED'}
         else:
            for obj in context.selected_objects:
                obj.location.y -= 1
            return {'FINISHED'}

class TranslateZ5(bpy.types.Operator):
    bl_idname = "object.translate_z_5"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.z += 5
            return {'FINISHED'}
         else:
            for obj in context.selected_objects:
                obj.location.z += 5
            return {'FINISHED'}

class TranslateZn5(bpy.types.Operator):
    bl_idname = "object.translate_z_n5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.z -= 5
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.location.z -= 5
            return {'FINISHED'}

class TranslateZ1(bpy.types.Operator):
    bl_idname = "object.translate_z_1"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.z += 1
            return {'FINISHED'}
         else:
            for obj in context.selected_objects:
                obj.location.z += 1
            return {'FINISHED'}

class TranslateZn1(bpy.types.Operator):
    bl_idname = "object.translate_z_n1"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                bone.location.z -= 1
            return {'FINISHED'}
         else:
            for obj in context.selected_objects:
                obj.location.z -= 1
            return {'FINISHED'}

class RotateX5(bpy.types.Operator):
    bl_idname = "object.rotate_x_5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[1] += 20 * (3.14159 / 180)
            
                else:                
                    bone.rotation_euler.x += 20 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.x += 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateX1(bpy.types.Operator):
    bl_idname = "object.rotate_x_1"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION' :
                   bone.rotation_quaternion[1] += 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.x += 5 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.x += 5 * (3.14159 / 180)
            return {'FINISHED'}

class RotateXn5(bpy.types.Operator):
    bl_idname = "object.rotate_x_n5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[1] -= 20 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.x -= 20 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.x -= 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateXn1(bpy.types.Operator):
    bl_idname = "object.rotate_x_n1"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[1] -= 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.x -= 5 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.x -= 5 * (3.14159 / 180)
            return {'FINISHED'}

class RotateY5(bpy.types.Operator):
    bl_idname = "object.rotate_y_5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[2] += 20 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.y += 20 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.y += 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateYn5(bpy.types.Operator):
    bl_idname = "object.rotate_y_n5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[2] -= 20 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.y -= 20 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.y -= 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateY1(bpy.types.Operator):
    bl_idname = "object.rotate_y_1"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[2] += 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.y += 5 * (3.14159 / 180)
            return {'FINISHED'}
         else:
            for obj in context.selected_objects:
                obj.rotation_euler.y += 5 * (3.14159 / 180)
            return {'FINISHED'}

class RotateYn1(bpy.types.Operator):
    bl_idname = "object.rotate_y_n1"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[2] -= 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.y -= 5 * (3.14159 / 180)
            return {'FINISHED'}
        else:
            for obj in context.selected_objects:
                obj.rotation_euler.y -= 5 * (3.14159 / 180)
            return {'FINISHED'}

class RotateZ5(bpy.types.Operator):
    bl_idname = "object.rotate_z_5"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[3] += 20 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.z += 20 * (3.14159 / 180)
            return {'FINISHED'}
        else: 
            for obj in context.selected_objects:
                obj.rotation_euler.z += 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateZn5(bpy.types.Operator):
    bl_idname = "object.rotate_z_n5"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[3] -= 20 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.z -= 20 * (3.14159 / 180)
            return {'FINISHED'}
         else: 
            for obj in context.selected_objects:
                obj.rotation_euler.z -= 20 * (3.14159 / 180)
            return {'FINISHED'}

class RotateZ1(bpy.types.Operator):
    bl_idname = "object.rotate_z_1"
    bl_label = ""

    def execute(self, context):
        if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[3] += 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.z += 5 * (3.14159 / 180)
            return {'FINISHED'}
        else: 
            for obj in context.selected_objects:
                obj.rotation_euler.z += 5 * (3.14159 / 180)
            return {'FINISHED'}

class RotateZn1(bpy.types.Operator):
    bl_idname = "object.rotate_z_n1"
    bl_label = ""

    def execute(self, context):
         if context.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.rotation_mode == 'QUATERNION':
                   bone.rotation_quaternion[3] -= 5 * (3.14159 / 180)
                else:                
                   bone.rotation_euler.z -= 5 * (3.14159 / 180)
            return {'FINISHED'}
         else: 
            for obj in context.selected_objects:
                obj.rotation_euler.z -= 5 * (3.14159 / 180)
            return {'FINISHED'}

# Register the operators

#mirror tool code

def get_opposite_suffix(name):
    suffixes = {
        'L': 'R', 'l': 'r', 'R': 'L', 'r': 'l',
        '_L': '_R', '_l': '_r', '_R': '_L', '_r': '_l',
        '.L': '.R', '.l': '.r', '.R': '.L', '.r': '.l'
    }
    for suffix, opposite in suffixes.items():
        if name.endswith(suffix):
            return name[:-len(suffix)] + opposite
    return None

def flip_value(value):
    return [-v for v in value]

def mirror_pose(context, flip_values=True, copy_mode=False, paste_mode=False, ik_mode=False):
    pose_bones = context.active_object.pose.bones 
    if context.mode == 'POSE' and context.active_object and context.active_object.type == 'ARMATURE':
        armature = context.active_object
        for bone in context.selected_pose_bones:
                bone.location.x *= -1    
    else:None

    if not pose_bones:
        return {'CANCELLED'}

    if copy_mode:
        context.scene.mirrored_pose_data.clear()

    for bone in pose_bones:
        if bone.bone.select:
            if copy_mode:
                data = context.scene.mirrored_pose_data.add()
                data.name = bone.name
                data.data = json.dumps({
                    'location': list(bone.location),
                    'rotation_quaternion': list(bone.rotation_quaternion),
                    'rotation_euler': list(bone.rotation_euler)
                })
            elif paste_mode:
                opposite_name = get_opposite_suffix(bone.name)
                if opposite_name:
                    data_item = next((item for item in context.scene.mirrored_pose_data if item.name == bone.name), None)
                    if data_item:
                        data = json.loads(data_item.data)
                        loc = mathutils.Vector(data['location'])
                        rot_quat = mathutils.Quaternion(data['rotation_quaternion'])
                        rot_euler = mathutils.Euler(data['rotation_euler'])

                        if flip_values:
                            loc = flip_value(loc)
                            rot_quat.conjugate()
                            rot_euler = flip_value(rot_euler)

                        if ik_mode:
                            loc[2] = data['location'][2]  # Keep Z location unflipped for IK mode

                        opposite_bone = pose_bones.get(opposite_name)
                        if opposite_bone:
                            opposite_bone.location = loc
                            opposite_bone.rotation_quaternion = rot_quat
                            opposite_bone.rotation_euler = rot_euler
            else:
                opposite_name = get_opposite_suffix(bone.name)
                if opposite_name:
                    opposite_bone = pose_bones.get(opposite_name)
                    if opposite_bone:
                        loc = bone.location.copy()
                        rot_quat = bone.rotation_quaternion.copy()
                        rot_euler = bone.rotation_euler.copy()

                        if flip_values:
                            loc = flip_value(loc)
                            rot_quat.conjugate()
                            rot_euler = flip_value(rot_euler)

                        if ik_mode:
                            loc[2] = bone.location[2]  # Keep Z location unflipped for IK mode

                        opposite_bone.location = loc
                        opposite_bone.rotation_quaternion = rot_quat
                        opposite_bone.rotation_euler = rot_euler
                elif not opposite_name and flip_values:
                    # Center bone (no suffix)
                    bone.location = flip_value(bone.location)
                    bone.rotation_quaternion.conjugate()
                    bone.rotation_euler = flip_value(bone.rotation_euler)

    return {'FINISHED'}

class MirroredPoseDataItem(bpy.types.PropertyGroup):
    name: StringProperty()
    data: StringProperty()

class POSE_OT_MirrorPose(bpy.types.Operator):
    bl_idname = "pose.mirror_pose"
    bl_label = "Mirror Pose"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context)

class POSE_OT_MirrorPoseIK(bpy.types.Operator):
    bl_idname = "pose.mirror_pose_ik"
    bl_label = "Mirror Pose (Suits IK)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context, ik_mode=True)

class POSE_OT_MirrorPoseUnflipped(bpy.types.Operator):
    bl_idname = "pose.mirror_pose_unflipped"
    bl_label = "Mirror Pose (Unflipped)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context, flip_values=False)

class POSE_OT_CopyPose(bpy.types.Operator):
    bl_idname = "pose.copy_pose"
    bl_label = "Copy Pose"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context, copy_mode=True)

class POSE_OT_PasteMirrorPose(bpy.types.Operator):
    bl_idname = "pose.paste_mirror_pose"
    bl_label = "Paste Mirror Pose"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context, paste_mode=True)

class POSE_OT_PasteMirrorPoseUnflipped(bpy.types.Operator):
    bl_idname = "pose.paste_mirror_pose_unflipped"
    bl_label = "Paste Mirror Pose (Unflipped)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return mirror_pose(context, flip_values=False, paste_mode=True)

class VIEW3D_PT_MirrorPosePanel(bpy.types.Panel):
    bl_label = "Mirror Pose Tools"
    bl_idname = "VIEW3D_PT_mirror_pose_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'animator_console'

    def draw(self, context):
        layout = self.layout
        layout.operator("pose.mirror_pose")
        layout.operator("pose.mirror_pose_ik")
        layout.operator("pose.mirror_pose_unflipped")
        layout.operator("pose.copy_pose")
        layout.operator("pose.paste_mirror_pose")
        layout.operator("pose.paste_mirror_pose_unflipped")

classes = (
    MirroredPoseDataItem,
    POSE_OT_MirrorPose,
    POSE_OT_MirrorPoseIK,
    POSE_OT_MirrorPoseUnflipped,
    POSE_OT_CopyPose,
    POSE_OT_PasteMirrorPose,
    POSE_OT_PasteMirrorPoseUnflipped,
    VIEW3D_PT_MirrorPosePanel
)

def register():
    bpy.utils.register_class(AnimatorConsolePanel)
    bpy.utils.register_class(TranslateX5)
    bpy.utils.register_class(TranslateX1)
    bpy.utils.register_class(TranslateXn5)
    bpy.utils.register_class(TranslateXn1)
    bpy.utils.register_class(TranslateY5)
    bpy.utils.register_class(TranslateYn5)
    bpy.utils.register_class(TranslateY1)
    bpy.utils.register_class(TranslateYn1)
    bpy.utils.register_class(TranslateZ5)
    bpy.utils.register_class(TranslateZn5)
    bpy.utils.register_class(TranslateZ1)
    bpy.utils.register_class(TranslateZn1)
    bpy.utils.register_class(RotateX5)
    bpy.utils.register_class(RotateX1)
    bpy.utils.register_class(RotateXn5)
    bpy.utils.register_class(RotateXn1)
    bpy.utils.register_class(RotateY5)
    bpy.utils.register_class(RotateYn5)
    bpy.utils.register_class(RotateY1)
    bpy.utils.register_class(RotateYn1)
    bpy.utils.register_class(RotateZ5)
    bpy.utils.register_class(RotateZn5)
    bpy.utils.register_class(RotateZ1)
    bpy.utils.register_class(RotateZn1)
    create_console_button()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mirrored_pose_data = CollectionProperty(type=MirroredPoseDataItem)

def unregister():
    bpy.utils.unregister_class(AnimatorConsolePanel)
    bpy.utils.unregister_class(TranslateX5)
    bpy.utils.unregister_class(TranslateX1)
    bpy.utils.unregister_class(TranslateXn5)
    bpy.utils.unregister_class(TranslateXn1)
    bpy.utils.unregister_class(TranslateY5)
    bpy.utils.unregister_class(TranslateYn5)
    bpy.utils.unregister_class(TranslateY1)
    bpy.utils.unregister_class(TranslateYn1)
    bpy.utils.unregister_class(TranslateZ5)
    bpy.utils.unregister_class(TranslateZn5)
    bpy.utils.unregister_class(TranslateZ1)
    bpy.utils.unregister_class(TranslateZn1)
    bpy.utils.unregister_class(RotateX5)
    bpy.utils.unregister_class(RotateX1)
    bpy.utils.unregister_class(RotateXn5)
    bpy.utils.unregister_class(RotateXn1)
    bpy.utils.unregister_class(RotateY5)
    bpy.utils.unregister_class(RotateYn5)
    bpy.utils.unregister_class(RotateY1)
    bpy.utils.unregister_class(RotateYn1)
    bpy.utils.unregister_class(RotateZ5)
    bpy.utils.unregister_class(RotateZn5)
    bpy.utils.unregister_class(RotateZ1)
    bpy.utils.unregister_class(RotateZn1)
    del bpy.types.WindowManager.open_console
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.mirrored_pose_data

if __name__ == "__main__":
    register()
# Animation Console Addon

## Overview

The Animation Console addon for Blender provides a convenient interface for animators to quickly manipulate object transformations (location and rotation) directly from the sidebar in the 3D Viewport. It also includes tools for mirroring poses, which can be particularly useful for character animation.

## Author
Syam Kalyan Yenubari

## Compatibility
Blender 4.1

## Dependencies
No additional dependencies are required beyond Blender 4.1.

## Features

- Quick transformation controls for location and rotation.
- Mirror pose tools including copy, paste, and flip options.
- Integrated within the 3D Viewport sidebar under the "Animator Console" tab.

## Installation

1. Download the addon as a zip file or `__init__.py`.
2. Open Blender.
3. Navigate to `Edit` > `Preferences`.
4. Go to the `Add-ons` tab.
5. Click `Install...` at the top right.
6. Select the `animation_console.zip` file (or `__init__.py` file if not zipped).
7. Ensure the checkbox next to the installed addon is checked to enable it.

## Usage

### Animator Console Panel

1. Open the 3D Viewport in Blender.
2. On the right sidebar, locate the `Animator Console` tab.
3. Check the "Open Console" checkbox to reveal the transformation controls.
4. Use the provided buttons to translate or rotate the selected objects along the X, Y, and Z axes in increments of 1 or 5 units/degrees.

### Mirror Pose Tools

1. Select an armature and enter Pose Mode.
2. In the sidebar under the `Animator Console` tab, use the following tools:
   - **Mirror Pose**: Mirrors the current pose to the opposite side.
   - **Mirror Pose (Suits IK)**: Mirrors the pose with IK (Inverse Kinematics) considerations.
   - **Mirror Pose (Unflipped)**: Mirrors the pose without flipping the values.
   - **Copy Pose**: Copies the current pose.
   - **Paste Mirror Pose**: Pastes the copied pose to the opposite side.
   - **Paste Mirror Pose (Unflipped)**: Pastes the copied pose without flipping the values.

## Operators

### Translation Operators

- `object.translate_x_5`: Translates the selected objects by +5 units on the X-axis.
- `object.translate_x_1`: Translates the selected objects by +1 unit on the X-axis.
- `object.translate_x_n5`: Translates the selected objects by -5 units on the X-axis.
- `object.translate_x_n1`: Translates the selected objects by -1 unit on the X-axis.
- `object.translate_y_5`: Translates the selected objects by +5 units on the Y-axis.
- `object.translate_y_1`: Translates the selected objects by +1 unit on the Y-axis.
- `object.translate_y_n5`: Translates the selected objects by -5 units on the Y-axis.
- `object.translate_y_n1`: Translates the selected objects by -1 unit on the Y-axis.
- `object.translate_z_5`: Translates the selected objects by +5 units on the Z-axis.
- `object.translate_z_1`: Translates the selected objects by +1 unit on the Z-axis.
- `object.translate_z_n5`: Translates the selected objects by -5 units on the Z-axis.
- `object.translate_z_n1`: Translates the selected objects by -1 unit on the Z-axis.

### Rotation Operators

- `object.rotate_x_5`: Rotates the selected objects by +20 degrees on the X-axis.
- `object.rotate_x_1`: Rotates the selected objects by +5 degrees on the X-axis.
- `object.rotate_x_n5`: Rotates the selected objects by -20 degrees on the X-axis.
- `object.rotate_x_n1`: Rotates the selected objects by -5 degrees on the X-axis.
- `object.rotate_y_5`: Rotates the selected objects by +20 degrees on the Y-axis.
- `object.rotate_y_1`: Rotates the selected objects by +5 degrees on the Y-axis.
- `object.rotate_y_n5`: Rotates the selected objects by -20 degrees on the Y-axis.
- `object.rotate_y_n1`: Rotates the selected objects by -5 degrees on the Y-axis.
- `object.rotate_z_5`: Rotates the selected objects by +20 degrees on the Z-axis.
- `object.rotate_z_1`: Rotates the selected objects by +5 degrees on the Z-axis.
- `object.rotate_z_n5`: Rotates the selected objects by -20 degrees on the Z-axis.
- `object.rotate_z_n1`: Rotates the selected objects by -5 degrees on the Z-axis.

## FAQ

**Q: What Blender versions are supported?**  
A: This addon is compatible with Blender 4.1 and above.

**Q: How do I report a bug?**  
A: Please report bugs by creating an issue on the [GitHub repository](#).

## Changelog

### Version 1.0.0
- Initial release with translation, rotation, and mirror pose tools.

## Known Issues

- The mirror pose tools may not work correctly with custom bone shapes or non-standard armatures.

## Support

For support, please contact [stugju@gmail.com] 

## License

This addon is licensed under the MIT License.
